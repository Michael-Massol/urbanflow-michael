import type { NextRequest } from "next/server";
import { updateSupabaseSession } from "@/modules/supabase/infrastructure/update-session";

export async function proxy(request: NextRequest) {
  return updateSupabaseSession(request);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|sw.js|hors-ligne|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
